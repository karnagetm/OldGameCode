






var space_x; // declaring 
var space_y; // declaring 

var alien_x = 50;
var alien_y = 300;


function setup() {
  // happens only once 
  createCanvas(700,400);
  // happens repeatedly 
  space_x = 100
  space_y = 200
}

function draw() {
  
  background(8); // set background colour 8-255
  
  text(random(), 40,20);
  
  
  // draw the spaceship
  fill(100) // color of space craft 
  rect(space_x,space_y,80,35); //x was 100, Y was 175
  
  // shape of space-craft
  
  rect(space_x + -20,space_y + 30,30,20); //x was 85, y was 165
  rect(space_x + -20,space_y + -10,30,20); //x was 58, y was 200
  
  space_x = space_x + 1;
  
  if(space_x > 400)
  {
     //action
    space_x = 0;
  }
  
  
  //mouseX 
  //mouseY
  
  
  for(var i=0; i < 10; i+=1)
    {
       drawAlien(alien_x + i * 40, alien_y);
    }
 
  
  //drawAlien(mouseX, mouseY);



  
  
  stroke('grey');
 strokeWeight(3);
 

  
  
}



function drawAlien (x,y){
  
   //drawing a Alien
  
  fill(82,7,7);
  
  rect(x - 15 ,y -15,30,30,);
  rect(x -15 ,y + 11,19,14);
 rect(x -19 ,y -16,15,17);
  rect(x +10 ,y -11,17,16);
  
  fill(0,0,0);
  
  ellipse(alien_x,  alien_y,  5, ); //for debugging
 
  
  
  
  
  
  
  
  
}