var space_x; 
var space_y; 
var alien_x = [];
var alien_y = [];
var alienSpeed = [];
var numAliens = 5;
var gameover = false;

function setup() {
  createCanvas(700, 400);
  space_x = 100;
  space_y = 200;

  // Initialize the position and speed of each asteroid
  for (var i = 0; i < numAliens; i++) {
    alien_x[i] = random(width, width * 2); // Start off-screen
    alien_y[i] = random(height);
    alienSpeed[i] = random(2, 5);
  }
}

function draw() {
  if (gameover) {
    background(0);
    fill(255);
    textSize(32);
    text("Game Over", width / 2 - 100, height / 2);
    return;
  }

  background(8);

  // Draw the spaceship
  fill(100);
  rect(space_x, space_y, 80, 35);
  rect(space_x - 20, space_y + 30, 30, 20);
  rect(space_x - 20, space_y - 10, 30, 20);

  // Control the spaceship
  if (keyIsDown(UP_ARROW) && space_y > 0) {
    space_y -= 3;
  }
  if (keyIsDown(DOWN_ARROW) && space_y < height - 35) {
    space_y += 3;
  }

  // Draw and move asteroids
  for (var i = 0; i < numAliens; i++) {
    drawAlien(alien_x[i], alien_y[i]);
    alien_x[i] -= alienSpeed[i];

    // Reset asteroid position if it moves off screen
    if (alien_x[i] < -30) {
      alien_x[i] = random(width, width * 2);
      alien_y[i] = random(height);
    }

    // Check for collision
    if (collideRectRect(space_x, space_y, 80, 35, alien_x[i] - 15, alien_y[i] - 15, 30, 30)) {
      gameover = true;
    }
  }
}

function drawAlien(x, y) {
  fill(82, 7, 7);
  rect(x - 15, y - 15, 30, 30);
  rect(x - 15, y + 11, 19, 14);
  rect(x - 19, y - 16, 15, 17);
  rect(x + 10, y - 11, 17, 16);
}

function collideRectRect(x1, y1, w1, h1, x2, y2, w2, h2) {
  return x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2;
}
